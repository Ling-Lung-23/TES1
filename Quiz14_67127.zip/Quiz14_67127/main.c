#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nama[50];
    char jurusan[30];
    int nilai;
} Siswa;

Siswa siswa[100];
int i = 0;

int compareNames(const void* a, const void* b) {
    const Siswa* s1 = (const Siswa*)a;
    const Siswa* s2 = (const Siswa*)b;
    return strcmp(s1->nama, s2->nama);
}

void quickSort(Siswa arr[], int low, int high) {
    if (low < high) {
        int pivot = partition(arr, low, high);
        quickSort(arr, low, pivot - 1);
        quickSort(arr, pivot + 1, high);
    }
}

int partition(Siswa arr[], int low, int high) {
    Siswa pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (compareNames(&arr[j], &pivot) <= 0) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }

    swap(&arr[i + 1], &arr[high]);
    return i + 1;
}

void swap(Siswa* a, Siswa* b) {
    Siswa temp = *a;
    *a = *b;
    *b = temp;
}

void bukaFileDatabase() {
    FILE* file;

    file = fopen("database_nilai.txt", "r");
    if (file == NULL) {
        printf("Gagal membuka file\n");
        return;
    }

    while (fscanf(file, "%[^😭]😭%[^😭]😭%d\n", siswa[i].nama, siswa[i].jurusan, &siswa[i].nilai) == 3) {
        i++;
    }
    fclose(file);
    quickSort(siswa, 0, i - 1);
}

void tampilkanMahasiswa() {
    printf("|---------------------------------------------------------------------------------|\n");
    printf("| No |\t\t\tNama\t\t\t|\t  Jurusan\t|  Nilai  |\n");
    printf("|---------------------------------------------------------------------------------|\n");
    for (int j = 0; j < i; j++) {
        printf("|%-3d | %-41s| %-22s| %-8d|\n", j, siswa[j].nama, siswa[j].jurusan, siswa[j].nilai );
    }
    printf("|---------------------------------------------------------------------------------|\n");
}

void binarySearch(const char* target) {
    int low = 0;
    int high = i - 1;
    int found = 0;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        char namaDepan[50];
        sscanf(siswa[mid].nama, "%s", namaDepan);
        int comparison = strcmp(target, namaDepan);

        if (comparison == 0) {
            printf("|---------------------------------------------------------------------------------|\n");
            printf("| No |\t\t\tNama\t\t\t|\t  Jurusan\t|  Nilai  |\n");
            printf("|---------------------------------------------------------------------------------|\n");
            printf("|%-3d | %-41s| %-22s| %-8d|\n", mid, siswa[mid].nama, siswa[mid].jurusan, siswa[mid].nilai );
            printf("|---------------------------------------------------------------------------------|\n");
            found = 1;
            break;
        } else if (comparison < 0) {
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }

    if (!found) {
        printf("\n\n !!! Mahasiswa dengan nama depan %s tidak ditemukan !!!\n", target);
    }
}

int main() {
    int a;
    char namaDepan[50];

    // Impor database
    bukaFileDatabase();

    while (1) {
        system("cls");
        printf("-------------- Manajemen Nilai Mahasiswa --------------\n");
        printf(" 1. Tampilkan semua mahasiswa \n");
        printf(" 2. Cari Mahasiswa \n");
        printf(" 3. Keluar Program \n");
        printf(" \n Silahkan masukkan pilihan Anda : ");
        scanf("%d", &a);

        switch (a) {
            case 1:
                tampilkanMahasiswa();
                getchar();
                printf("\n ----- Ketik tombol apa saja untuk melanjutkan");
                getchar();
                break;
            case 2:
                printf("\n\n Masukkan nama depan mahasiswa yang ingin dicari: ");
                scanf("%s", namaDepan);
                getchar();
                binarySearch(namaDepan);
                printf("\n ----- Ketik tombol apa saja untuk melanjutkan");
                getchar();
                break;
        break;
            case 3:
                printf(" \n !! Terimakasih telah berkunjung !!\n");
                return 0;
            default:
                printf(" Pilihan tidak valid\n");
                break;
        }
    }

    return 0;
}
